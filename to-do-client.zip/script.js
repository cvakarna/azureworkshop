let currentUser = null;
let todos = [];
let apiUrl = 'http://localhost:5020/ToDo';
let userid = null;

// Function to display todo card
function showTodoCard() {
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('todo-card').style.display = 'block';
  document.getElementById('profile1').style.display = 'block';
  
  document.getElementById('user-name').innerHTML = currentUser.userName;
  let profile = document.getElementById('profilepic');
   profile.src = currentUser.profilePic;
  
  
  fetch(apiUrl,{
	  
	   method: "GET",
	   headers: {"userid":currentUser.userId}
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
	
    return response.json();
  })
  .then(data => {
	  console.log(data);
    // Handle the data (e.g., display it in an HTML element)
	
	const todoList = document.getElementById('todo-list');
	for (let i = 0; i < data.length; i++) {
        const li = document.createElement('li');
		  li.className = 'list-group-item';
		  li.innerHTML = `
			<h5>${data[i].title}</h5>
			<p>Description: ${data[i].description}</p>
			<p>Date: ${data[i].datetime}</p>
			<button type="button" class="btn btn-sm btn-danger float-right ml-2" onclick="deleteTodo(this)">Delete</button>
			<button type="button" class="btn btn-sm btn-primary float-right" onclick="editTodo(this)">Edit</button>
		  `;
		  todoList.appendChild(li);
		  todos.push(data[i]);
    }
	
  })
  .catch(error => {
    console.error('Error:', error);
  });
  
}

// Function to add todo
function addTodo(todoTitle, todoDescription, todoDate) {
  const todoList = document.getElementById('todo-list');
  const li = document.createElement('li');
  li.className = 'list-group-item';
  li.innerHTML = `
    <h5>${todoTitle}</h5>
    <p>Description: ${todoDescription}</p>
    <p>Date: ${todoDate}</p>
    <button type="button" class="btn btn-sm btn-danger float-right ml-2" onclick="deleteTodo(this)">Delete</button>
    <button type="button" class="btn btn-sm btn-primary float-right" onclick="editTodo(this)">Edit</button>
  `;
  todoList.appendChild(li);
}

// Function to delete todo
function deleteTodo(button) {
  const li = button.parentElement;
  const index = Array.from(li.parentElement.children).indexOf(li);
  li.remove();
 
  console.log("deletedList:"+todos[index]);
  fetch(apiUrl+"/"+todos[index].id,{
	  
	   method: "DELETE",
	   headers: {"userid":currentUser.userId}
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
	
    return response.json();
  })
  .then(data => {
	  console.log(data);
    // Handle the data (e.g., display it in an HTML element)
	
	
  })
  .catch(error => {
    console.error('Error:', error);
  });
  
  
}

// Function to edit todo
function editTodo(button) {
  const li = button.parentElement;
  const index = Array.from(li.parentElement.children).indexOf(li);
  const editedTodo = todos[index];
  const newTitle = prompt('Enter new title:');
  const newDescription = prompt('Enter new description:');
  const newDate = prompt('Enter new date (YYYY-MM-DD):');
  if (newTitle !== null && newTitle.trim() !== '' && newDate !== null && newDate.trim() !== '') {
    li.querySelector('h5').innerText = newTitle;
    li.querySelector('p:nth-child(2)').innerText = `Description: ${newDescription}`;
    li.querySelector('p:nth-child(3)').innerText = `Date: ${newDate}`;
    todos[index] = { title: newTitle, description: newDescription, datetime: newDate,id:editedTodo.id,userId:currentUser.userId };
	
	
		  //send to backend 
	fetch(apiUrl,{
	  
	   method: "PUT",
	   headers: {"userid":currentUser.userId,"Content-Type": "application/json"},
	   
	   body: JSON.stringify(todos[index])
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
	
    return response.json();
  })
  .then(data => {
	  console.log(data);
    // Handle the data (e.g., display it in an HTML element)
	
    }
	
  )
  .catch(error => {
    console.error('Error:', error);
  });
	
	
	
	
  }
}

// Event listener for login form submission
document.getElementById('login-form').addEventListener('submit', function(event) {
  event.preventDefault();
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  // Here, you can add your authentication logic
  // For simplicity, let's just consider it successful login
  currentUser = { email }; // Simulate user object
  
  

     //send to backend 
	fetch(apiUrl+"/login",{
	  
	   method: "POST",
	   headers: {"Content-Type": "application/json"},
	   
	   body: JSON.stringify({ Email: email, Password: password})
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
	
    return response.json();
  })
  .then(data => {
	  console.log(data);
	  currentUser = data;
	  // After successful login
  document.getElementById('login').style.display = 'none';
    // Handle the data (e.g., display it in an HTML element)
	  showTodoCard();
	   
    }
	
  )
  .catch(error => {
    console.error('Error:', error);
	alert("redetnails are wrong or something went wrong, please try once again");
  });
	





  
});

// Event listener for todo form submission
document.getElementById('todo-form').addEventListener('submit', function(event) {
  event.preventDefault();
  const todoTitle = document.getElementById('todo-input').value.trim();
  const todoDescription = document.getElementById('todo-description').value.trim();
  const todoDate = document.getElementById('todo-date').value;
  const id = crypto.randomUUID();
  if (todoTitle !== '' && todoDate !== '') {
	  
	  //send to backend 
	fetch(apiUrl,{
	  
	   method: "POST",
	   headers: {"userid":currentUser.userId,"Content-Type": "application/json"},
	   
	   body: JSON.stringify({ title: todoTitle, description: todoDescription, datetime: todoDate, id:id,userId: currentUser.userId})
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
	
    return response.json();
  })
  .then(data => {
	  console.log(data);
    // Handle the data (e.g., display it in an HTML element)
	
	   addTodo(todoTitle, todoDescription, todoDate);
       todos.push({ title: todoTitle, description: todoDescription, datetime: todoDate, id:id });
       document.getElementById('todo-form').reset();
    }
	
  )
  .catch(error => {
    console.error('Error:', error);
  });
	
	
	  
	  
	  
	  
    // addTodo(todoTitle, todoDescription, todoDate);
    // todos.push({ title: todoTitle, description: todoDescription, date: todoDate });
    // document.getElementById('todo-form').reset();
  }
  
});
